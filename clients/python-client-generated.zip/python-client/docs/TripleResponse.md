# TripleResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rows** | **list[object]** | Query results | [optional] 
**count** | **int** | Number of rows returned | [optional] 
**elapsed** | **int** | Nanoseconds elapsed during evaluation | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


